const express = require('express');
const sql = require('mssql');
const { Connection, Request } = require('tedious');
const app = express();
const port = 3000;

const config = {
  server: 'localhost', // Update to use the host where your Docker container is running
  database: 'clinic_database',
  options: {
    trustedConnection: true,
    enableArithAbort: true,
    encrypt: true,
    trustServerCertificate: true,
  },
};

// Create a connection to the database using the tedious library
const connection = new Connection(config);

connection.on('connect', (err) => {
  if (err) {
    console.error('Error connecting to SQL Server:', err.message);
  } else {
    console.log('Connected to SQL Server');
  }
});

// Middleware to parse form data
app.use(express.urlencoded({ extended: false }));

// Serve static files (your HTML, CSS, and other assets)
app.use(express.static('public'));

// Handle POST request from your HTML form
app.post('/add-patient', async (req, res) => {
  // Get data from the form
  const { name, phone, age, branch, doctor, diagnosis, gender, generalNotes, sessionNotes } = req.body;

  try {
    // Connect to the SQL Server
    await sql.connect(config);
  
    // Insert the data into the Patients table
    const result = await sql.query`INSERT INTO Patients (patient_name, phone_number, age, branch, DoctorID, diagnosis, gender, general_notes, session_notes)
    VALUES(${name}, ${phone}, ${age}, ${branch}, ${doctor}, ${diagnosis}, ${gender}, ${generalNotes}, ${sessionNotes})`;
  
    console.log('Data inserted successfully');
    res.send('Data inserted successfully');
  } catch (error) {
    console.error('Error inserting data:', error.message); // Log the detailed error message
    res.send('Error inserting data');
  } finally {
    // Close the SQL Server connection
    await sql.close();
  }
  
});

// Start the server
app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
