const tls = require('tls');
const fs = require('fs');
const sql = require('mssql');

// Load the exported certificate and key
const cert = fs.readFileSync('C:\\Windows\\system32\\test_connection.pfx');
const passphrase = ''; // Set the password you used during export

const tlsConfig = {
  key: cert,
  passphrase: passphrase,
  pfx: cert,
};

const config = {
  server: 'DESKTOP-0GS76H4',
  database: 'clinic_database',
  options: {
    trustedConnection: true,
    enableArithAbort: true,
    encrypt: true,
  },
};


async function testConnection() {
  try {
    const pool = await sql.connect(config);

    // Execute a simple test query
    const result = await pool.request().query('SELECT 1 AS TestValue');

    console.log('Connection successful');
    console.log('Test query result:', result.recordset[0].TestValue);
  } catch (error) {
    console.error('Connection error:', error.message);
  } finally {
    sql.close();
  }
}

testConnection();
